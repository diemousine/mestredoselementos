-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2021 at 02:12 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u216684008_mde`
--

-- --------------------------------------------------------

--
-- Table structure for table `cartas`
--

CREATE TABLE `cartas` (
  `idcartas` int(11) NOT NULL,
  `nome` varchar(15) NOT NULL COMMENT 'Nome do elemento.',
  `simbolo` varchar(3) NOT NULL DEFAULT '' COMMENT 'Simbolo do elemento.',
  `num_atom` int(11) NOT NULL COMMENT 'Número atômico do elemento.',
  `periodo` int(11) NOT NULL COMMENT 'Período do elemento.',
  `familia` int(11) NOT NULL COMMENT 'Família do elemento.',
  `eletrons` varchar(20) DEFAULT NULL COMMENT 'Distribuição eletrônica do elemento.',
  `mas_atom` float DEFAULT NULL COMMENT 'Massa atômica do elemento.',
  `num_neu` int(11) DEFAULT NULL COMMENT 'Número de protons para Isotopos.',
  `class` enum('1','2','3','4') NOT NULL DEFAULT '1' COMMENT 'Classificação do elemento: 1 - comum, 2 - rara, 3 - muito rara, 4 - desconhedas.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Elementos da tabela periodica e suas devidas características físicas.';

--
-- Dumping data for table `cartas`
--

INSERT INTO `cartas` (`idcartas`, `nome`, `simbolo`, `num_atom`, `periodo`, `familia`, `eletrons`, `mas_atom`, `num_neu`, `class`) VALUES
(1, 'Hidrogênio', 'H', 1, 1, 1, '1', 1.00794, NULL, '1'),
(2, 'Hélio', 'He', 2, 1, 18, '2', 4.0026, NULL, '1'),
(3, 'Lítio', 'Li', 3, 2, 1, '2,1', 6.941, NULL, '1'),
(4, 'Berílio', 'Be', 4, 2, 2, '2,2', 9.01218, NULL, '1'),
(5, 'Boro', 'B', 5, 2, 13, '2,3', 10.811, NULL, '1'),
(6, 'Carbono', 'C', 6, 2, 14, '2,4', 12.0107, NULL, '1'),
(7, 'Nitrogênio', 'N', 7, 2, 15, '2,5', 14.0067, NULL, '1'),
(8, 'Oxigênio', 'O', 8, 2, 16, '2,6', 15.9994, NULL, '1'),
(9, 'Flúor', 'F', 9, 2, 17, '2,7', 18.9984, NULL, '1'),
(10, 'Neônio', 'Ne', 10, 2, 18, '2,8', 20.1797, NULL, '1'),
(11, 'Sódio', 'Na', 11, 3, 1, '2,8,1', 22.9898, NULL, '1'),
(12, 'Magnésio', 'Mg', 12, 3, 2, '2,8,2', 24.305, NULL, '1'),
(13, 'Alumínio', 'Al', 13, 3, 13, '2,8,3', 26.9815, NULL, '1'),
(14, 'Silício', 'Si', 14, 3, 14, '2,8,4', 28.0855, NULL, '1'),
(15, 'Fósforo', 'P', 15, 3, 15, '2,8,5', 30.9738, NULL, '1'),
(16, 'Enxofre', 'S', 16, 3, 16, '2,8,6', 32.065, NULL, '1'),
(17, 'Cloro', 'Cl', 17, 3, 17, '2,8,7', 35.453, NULL, '1'),
(18, 'Argônio', 'Ar', 18, 3, 18, '2,8,8', 39.948, NULL, '1'),
(19, 'Potássio', 'K', 19, 4, 1, '2,8,8,1', 39.0983, NULL, '1'),
(20, 'Cálcio', 'Ca', 20, 4, 2, '2,8,8,2', 40.078, NULL, '1'),
(21, 'Escândio', 'Sc', 21, 4, 3, '2,8,9,2', 44.9559, NULL, '1'),
(22, 'Titânio', 'Ti', 22, 4, 4, '2,8,10,2', 47.867, NULL, '1'),
(23, 'Vanádio', 'V', 23, 4, 5, '2,8,11,2', 50.9415, NULL, '1'),
(24, 'Crômo', 'Cr', 24, 4, 6, '2,8,13,1', 51.9961, NULL, '1'),
(25, 'Manganês', 'Mn', 25, 4, 7, '2,8,13,2', 54.938, NULL, '1'),
(26, 'Ferro', 'Fe', 26, 4, 8, '2,8,14,2', 55.845, NULL, '1'),
(27, 'Cobalto', 'Co', 27, 4, 9, '2,8,15,2', 58.9332, NULL, '1'),
(28, 'Níquel', 'Ni', 28, 4, 10, '2,8,16,2', 58.6934, NULL, '1'),
(29, 'Cobre', 'Cu', 29, 4, 11, '2,8,18,1', 63.546, NULL, '1'),
(30, 'Zinco', 'Zn', 30, 4, 12, '2,8,18,2', 63.38, NULL, '1'),
(31, 'Gálio', 'Ga', 31, 4, 13, '2,8,18,3', 69.723, NULL, '1'),
(32, 'Germânio', 'Ge', 32, 4, 14, '2,8,18,4', 72.63, NULL, '1'),
(33, 'Arsênio', 'As', 33, 4, 15, '2,8,18,5', 74.9216, NULL, '1'),
(34, 'Selênio', 'Se', 34, 4, 16, '2,8,18,6', 78.96, NULL, '1'),
(35, 'Bromo', 'Br', 35, 4, 17, '2,8,18,7', 79.904, NULL, '1'),
(36, 'Cripitônio', 'Kr', 36, 4, 18, '2,8,18,8', 83.798, NULL, '1'),
(37, 'Rubídio', 'Rb', 37, 5, 1, '2,8,18,8,1', 85.4678, NULL, '1'),
(38, 'Estrôncio', 'Sr', 38, 5, 2, '2,8,18,8,2', 87.62, NULL, '1'),
(39, 'Ítrio', 'Y', 39, 5, 3, '2,8,18,9,2', 88.9059, NULL, '1'),
(40, 'Zircônio', 'Zr', 40, 5, 4, '2,8,18,10,2', 91.224, NULL, '1'),
(41, 'Nióbio', 'Nb', 41, 5, 5, '2,8,18,12,1', 92.9064, NULL, '1'),
(42, 'Molibdênio', 'Mo', 42, 5, 6, '2,8,18,13,1', 95.96, NULL, '1'),
(43, 'Tecnécio', 'Tc', 43, 5, 7, '2,8,18,13,2', 98, NULL, '1'),
(44, 'Rutênio', 'Ru', 44, 5, 8, '2,8,18,15,1', 101.07, NULL, '1'),
(45, 'Ródio', 'Rh', 45, 5, 9, '2,8,18,16,1', 102.906, NULL, '1'),
(46, 'Paládio', 'Pd', 46, 5, 10, '2,8,18,18', 106.42, NULL, '1'),
(47, 'Prata', 'Ag', 47, 5, 11, '2,8,18,18,1', 107.868, NULL, '1'),
(48, 'Cádmio', 'Cd', 48, 5, 12, '2,8,18,18,2', 112.411, NULL, '1'),
(49, 'Índio', 'In', 49, 5, 13, '2,8,18,18,3', 114.818, NULL, '1'),
(50, 'Estanho', 'Sn', 50, 5, 14, '2,8,18,18,4', 118.71, NULL, '1'),
(51, 'Antimônio', 'Sb', 51, 5, 15, '2,8,18,18,5', 121.76, NULL, '1'),
(52, 'Telúrio', 'Te', 52, 5, 16, '2,8,18,18,6', 127.6, NULL, '1'),
(53, 'Iodo', 'I', 53, 5, 17, '2,8,18,18,7', 126.904, NULL, '1'),
(54, 'Xenônio', 'Xe', 54, 5, 18, '2,8,18,18,8', 131.293, NULL, '1'),
(55, 'Césio', 'Cs', 55, 6, 1, '2,8,18,18,8,1', 132.905, NULL, '1'),
(56, 'Bário', 'Ba', 56, 6, 2, '2,8,18,18,8,2', 137.327, NULL, '1'),
(57, 'Lantânio', 'La', 57, 6, 3, '2,8,18,18,9,2', 138.905, NULL, '1'),
(58, 'Cério', 'Ce', 58, 6, 3, '2,8,18,19,9,2', 140.116, NULL, '1'),
(59, 'Praseodímio', 'Pr', 59, 6, 3, '2,8,18,21,8,2', 140.908, NULL, '1'),
(60, 'Neodímio', 'Nd', 60, 6, 3, '2,8,18,22,8,2', 144.242, NULL, '1'),
(61, 'Promécio', 'Pm', 61, 6, 3, '2,8,18,23,8,2', 145, NULL, '1'),
(62, 'Samário', 'Sm', 62, 6, 3, '2,8,18,24,8,2', 150.36, NULL, '1'),
(63, 'Európio', 'Eu', 63, 6, 3, '2,8,18,25,8,2', 151.964, NULL, '1'),
(64, 'Gadolínio', 'Gd', 64, 6, 3, '2,8,18,25,9,2', 157.25, NULL, '1'),
(65, 'Térbio', 'Tb', 65, 6, 3, '2,8,18,27,8,2', 158.925, NULL, '1'),
(66, 'Disprósio', 'Dy', 66, 6, 3, '2,8,18,28,8,2', 162.5, NULL, '1'),
(67, 'Hólmio', 'Ho', 67, 6, 3, '2,8,18,29,8,2', 164.93, NULL, '1'),
(68, 'Érbio', 'Er', 68, 6, 3, '2,8,18,30,8,2', 167.259, NULL, '1'),
(69, 'Túlio', 'Tm', 69, 6, 3, '2,8,18,31,8,2', 168.934, NULL, '1'),
(70, 'Itérbio', 'Yb', 70, 6, 3, '2,8,18,32,8,2', 173.054, NULL, '1'),
(71, 'Lutécio', 'Lu', 71, 6, 3, '2,8,18,32,9,2', 174.967, NULL, '1'),
(72, 'Háfnio', 'Hf', 72, 6, 4, '2,8,18,32,10,2', 178.49, NULL, '1'),
(73, 'Tântalo', 'Ta', 73, 6, 5, '2,8,18,32,11,2', 180.948, NULL, '1'),
(74, 'Tungstênio', 'W', 74, 6, 6, '2,8,18,32,12,2', 183.84, NULL, '1'),
(75, 'Rênio', 'Re', 75, 6, 7, '2,8,18,32,13,2', 186.207, NULL, '1'),
(76, 'Ósmio', 'Os', 76, 6, 8, '2,8,18,32,14,2', 190.23, NULL, '1'),
(77, 'Irídio', 'Ir', 77, 6, 9, '2,8,18,32,15,2', 192.217, NULL, '1'),
(78, 'Platina', 'Pt', 78, 6, 10, '2,8,18,32,17,1', 195.084, NULL, '1'),
(79, 'Ouro', 'Au', 79, 6, 11, '2,8,18,32,18,1', 196.967, NULL, '1'),
(80, 'Mercúrio', 'Hg', 80, 6, 12, '2,8,18,32,18,2', 200.59, NULL, '1'),
(81, 'Tálio', 'Tl', 81, 6, 13, '2,8,18,32,18,3', 204.383, NULL, '1'),
(82, 'Chumbo', 'Pb', 82, 6, 14, '2,8,18,32,18,4', 207.2, NULL, '1'),
(83, 'Bismuto', 'Bi', 83, 6, 15, '2,8,18,32,18,5', 208.98, NULL, '1'),
(84, 'Polônio', 'Po', 84, 6, 16, '2,8,18,32,18,6', 209, NULL, '1'),
(85, 'Astato', 'At', 85, 6, 17, '2,8,18,32,18,7', 210, NULL, '1'),
(86, 'Radônio', 'Rn', 86, 6, 18, '2,8,18,32,18,8', 222, NULL, '1'),
(87, 'Frâncio', 'Fr', 87, 7, 1, '2,8,18,32,18,8,1', 223, NULL, '1'),
(88, 'Rádio', 'Ra', 88, 7, 2, '2,8,18,32,18,8,2', 226, NULL, '1'),
(89, 'Actínio', 'Ac', 89, 7, 3, '2,8,18,32,18,9,2', 227, NULL, '1'),
(90, 'Tório', 'Th', 90, 7, 3, '2,8,18,32,18,10,2', 232.038, NULL, '1'),
(91, 'Protactínio', 'Pa', 91, 7, 3, '2,8,18,32,20,9,2', 231.036, NULL, '1'),
(92, 'Urânio', 'U', 92, 7, 3, '2,8,18,32,21,9,2', 238.029, NULL, '1'),
(93, 'Neptúnio', 'Np', 93, 7, 3, '2,8,18,32,22,9,2', 237, NULL, '1'),
(94, 'Plutônio', 'Pu', 94, 7, 3, '2,8,18,32,24,8,2', 244, NULL, '1'),
(95, 'Amerício', 'Am', 95, 7, 3, '2,8,18,32,25,8,2', 243, NULL, '1'),
(96, 'Cúrio', 'Cm', 96, 7, 3, '2,8,18,32,25,9,2', 247, NULL, '1'),
(97, 'Berquélio', 'Bk', 97, 7, 3, '2,8,18,32,27,8,2', 247, NULL, '1'),
(98, 'Califórnio', 'Cf', 98, 7, 3, '2,8,18,32,28,8,2', 251, NULL, '1'),
(99, 'Einstênio', 'Es', 99, 7, 3, '2,8,18,32,29,8,2', 252, NULL, '1'),
(100, 'Férmio', 'Fm', 100, 7, 3, '2,8,18,32,30,8,2', 257, NULL, '1'),
(101, 'Mendelévio', 'Md', 101, 7, 3, '2,8,18,32,31,8,2', 258, NULL, '1'),
(102, 'Nobélio', 'No', 102, 7, 3, '2,8,18,32,32,8,2', 259, NULL, '1'),
(103, 'Laurêncio', 'Lr', 103, 7, 3, '2,8,18,32,32,8,3', 262, NULL, '1'),
(104, 'Rutherfórdio', 'Rf', 104, 7, 4, '2,8,18,32,32,10,2', 267, NULL, '1'),
(105, 'Dúbnio', 'Db', 105, 7, 5, '2,8,18,32,32,11,2', 268, NULL, '1'),
(106, 'Seabórgio', 'Sg', 106, 7, 6, '2,8,18,32,32,12,2', 271, NULL, '1'),
(107, 'Bóhrio', 'Bh', 107, 7, 7, '2,8,18,32,32,13,2', 272, NULL, '1'),
(108, 'Hássio', 'Hs', 108, 7, 8, '2,8,18,32,32,14,2', 270, NULL, '1'),
(109, 'Meitnério', 'Mt', 109, 7, 9, '2,8,18,32,32,15,2', 276, NULL, '1'),
(110, 'Darmstádio', 'Ds', 110, 7, 10, '2,8,18,32,32,17,1', 281, NULL, '1'),
(111, 'Roentgênio', 'Rg', 111, 7, 11, '2,8,18,32,32,18,1', 280, NULL, '1'),
(112, 'Copernício', 'Cn', 112, 7, 12, '2,8,18,32,32,18,2', 285, NULL, '1'),
(113, 'Ununtrio', 'Uut', 113, 7, 13, '2,8,18,32,32,18,3', 284, NULL, '1'),
(114, 'Fleróvio', 'Fl', 114, 7, 14, '2,8,18,32,32,18,4', 289, NULL, '1'),
(115, 'Ununpentio', 'Uup', 115, 7, 15, '2,8,18,32,32,18,5', 288, NULL, '1'),
(116, 'Livermório', 'Lv', 116, 7, 16, '2,8,18,32,32,18,6', 293, NULL, '1'),
(117, 'Ununséptio', 'Uus', 117, 7, 17, '2,8,18,32,32,18,7', 294, NULL, '1'),
(118, 'Ununóctio', 'Uuo', 118, 7, 18, '2,8,18,32,32,18,8', 294, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `duelo`
--

CREATE TABLE `duelo` (
  `idpartida` int(11) NOT NULL,
  `idduelo` varchar(32) NOT NULL,
  `inicio` int(11) NOT NULL,
  `fim` int(11) NOT NULL,
  `iddesaf` int(11) NOT NULL,
  `deckdes` varchar(62) NOT NULL,
  `cartadesaf` varchar(3) NOT NULL DEFAULT '0',
  `maodes` varchar(23) NOT NULL DEFAULT '0',
  `ptdesaf` int(11) NOT NULL DEFAULT 0,
  `idopon` int(11) NOT NULL,
  `deckopon` varchar(62) NOT NULL,
  `cartaopon` varchar(3) NOT NULL DEFAULT '0',
  `maoopon` varchar(23) NOT NULL DEFAULT '0',
  `ptopon` int(11) DEFAULT 0,
  `ttlmao` int(11) NOT NULL DEFAULT 10,
  `maoatual` int(11) NOT NULL DEFAULT 1,
  `propriedade` enum('raio','ener-ionizacao','afinidade','negatividade','positividade','pote-ionizacao') DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `mudastatus` int(11) NOT NULL,
  `idvencedor` int(11) DEFAULT NULL,
  `idperdedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Registra todos os dados do duelo.';

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `idlogin` int(11) NOT NULL,
  `email` varchar(100) NOT NULL COMMENT 'Email do usuário.',
  `senha` varchar(32) NOT NULL COMMENT 'Senha criptografada em sha e md5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Somente os dados de login dos usuários. Todos os dados são criptografados.';

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`idlogin`, `email`, `senha`) VALUES
(1, 'ia@w3aplicativos.com.br', '755fec9d85c31516bd87f6f9074951c2');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `idlogin` int(11) NOT NULL COMMENT 'Foreign Keys da tabela login',
  `nome` varchar(15) NOT NULL COMMENT 'Nome do usuário.',
  `sobrenome` varchar(45) NOT NULL,
  `sexo` enum('Masculino','Feminino','','') DEFAULT NULL,
  `nascimento` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Data de nascimento do usuário.',
  `serie` varchar(100) NOT NULL COMMENT 'Nível escolar o usuário.',
  `experiencia` int(11) NOT NULL DEFAULT 0 COMMENT 'Experiência já conquistada no jogo.',
  `nivel` int(11) NOT NULL DEFAULT 1 COMMENT 'Nível conquistado no jogo.',
  `cartas` varchar(475) NOT NULL COMMENT 'Lista com os números das cartas já adiquiridas. (separar por virgula)',
  `deck` varchar(62) NOT NULL,
  `status` enum('jogando','esperando','online','offline') NOT NULL DEFAULT 'online'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Dados pessoais dos usuários. Todos os campos são requeridos.';

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`idusuario`, `idlogin`, `nome`, `sobrenome`, `sexo`, `nascimento`, `serie`, `experiencia`, `nivel`, `cartas`, `deck`, `status`) VALUES
(1, 1, 'Mestre', 'dos Elementos', 'Masculino', '1986-06-01 00:00:00', '8:Ciências da Computação', 0, 1, '49,036,047,037,092,088,059,031,053,017,113,071,001,074,070,090,095,010,085,107,061,024,075,056,087,093,112,033,100,016,118,099,030,067,035,077,081,106,086,028,039,026,054,058,019,079,052,066,013,004', '', 'offline');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cartas`
--
ALTER TABLE `cartas`
  ADD PRIMARY KEY (`idcartas`),
  ADD UNIQUE KEY `nome_UNIQUE` (`nome`);

--
-- Indexes for table `duelo`
--
ALTER TABLE `duelo`
  ADD PRIMARY KEY (`idpartida`),
  ADD KEY `duelo_iddesaf_idx` (`iddesaf`),
  ADD KEY `duelo_idopon_idx` (`idopon`),
  ADD KEY `duelo_iddavez_idx` (`status`),
  ADD KEY `duelo_vencedor_idx` (`idvencedor`),
  ADD KEY `duelo_perdedor_idx` (`idperdedor`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`idlogin`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`),
  ADD UNIQUE KEY `idlogin_UNIQUE` (`idlogin`),
  ADD KEY `idlogin_usuario_login_idx` (`idlogin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cartas`
--
ALTER TABLE `cartas`
  MODIFY `idcartas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `duelo`
--
ALTER TABLE `duelo`
  MODIFY `idpartida` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `idlogin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `duelo`
--
ALTER TABLE `duelo`
  ADD CONSTRAINT `duelo_iddavez` FOREIGN KEY (`status`) REFERENCES `usuario` (`idusuario`),
  ADD CONSTRAINT `duelo_iddesaf` FOREIGN KEY (`iddesaf`) REFERENCES `usuario` (`idusuario`),
  ADD CONSTRAINT `duelo_idopon` FOREIGN KEY (`idopon`) REFERENCES `usuario` (`idusuario`),
  ADD CONSTRAINT `duelo_perdedor` FOREIGN KEY (`idperdedor`) REFERENCES `usuario` (`idusuario`),
  ADD CONSTRAINT `duelo_vencedor` FOREIGN KEY (`idvencedor`) REFERENCES `usuario` (`idusuario`);

--
-- Constraints for table `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `idlogin_usuario_login` FOREIGN KEY (`idlogin`) REFERENCES `login` (`idlogin`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
